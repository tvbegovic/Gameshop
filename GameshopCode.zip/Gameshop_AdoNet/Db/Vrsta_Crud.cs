﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;


namespace Gameshop_AdoNet.Db
{
	public class Vrsta_Crud
	{
		public List<Genre> GetAll()
		{
			return null;
		}
	}
}
