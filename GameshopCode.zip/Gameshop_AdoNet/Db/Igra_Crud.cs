﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace Gameshop_AdoNet.Db
{
	public class Igra_Crud
	{
		//Implementirati metode GetAll, GetById, Insert, Update, Delete
		public List<Game> GetAll()
		{
			return null;
		}

		public Game GetById(int id)
		{
			return null;
		}

		public int Insert(Game igra)
		{
			return 0;
		}

		public void Update(Game igra)
		{

		}

		public void Delete(int id)
		{

		}
	}
	
}
