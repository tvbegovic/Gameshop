﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gameshop_AdoNet.Db
{
	//Ovdje pastati kod klasa dobivenih SQL skriptom
	public class Game
	{
		
	}

	public class Genre
	{

	}

	public class Company
	{

	}
}
