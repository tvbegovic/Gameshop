﻿
namespace Gameshop_AdoNet
{
	partial class IgreEdit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IgreEdit));
			this.txtDatumIzdavanja = new System.Windows.Forms.TextBox();
			this.iDLabel = new System.Windows.Forms.Label();
			this.txtId = new System.Windows.Forms.TextBox();
			this.nazivLabel = new System.Windows.Forms.Label();
			this.txtNaziv = new System.Windows.Forms.TextBox();
			this.idIzdavacLabel = new System.Windows.Forms.Label();
			this.idDeveloperLabel = new System.Windows.Forms.Label();
			this.cijenaLabel = new System.Windows.Forms.Label();
			this.txtCijena = new System.Windows.Forms.TextBox();
			this.datumIzdavanjaLabel = new System.Windows.Forms.Label();
			this.idVrstaIgreLabel = new System.Windows.Forms.Label();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.tsbSpremi = new System.Windows.Forms.ToolStripButton();
			this.tsbCancel = new System.Windows.Forms.ToolStripButton();
			this.cboVrsta = new System.Windows.Forms.ComboBox();
			this.cboIzdavac = new System.Windows.Forms.ComboBox();
			this.cboDeveloper = new System.Windows.Forms.ComboBox();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtDatumIzdavanja
			// 
			this.txtDatumIzdavanja.Location = new System.Drawing.Point(128, 141);
			this.txtDatumIzdavanja.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtDatumIzdavanja.Name = "txtDatumIzdavanja";
			this.txtDatumIzdavanja.Size = new System.Drawing.Size(233, 23);
			this.txtDatumIzdavanja.TabIndex = 21;
			// 
			// iDLabel
			// 
			this.iDLabel.AutoSize = true;
			this.iDLabel.Location = new System.Drawing.Point(16, 51);
			this.iDLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.iDLabel.Name = "iDLabel";
			this.iDLabel.Size = new System.Drawing.Size(21, 15);
			this.iDLabel.TabIndex = 16;
			this.iDLabel.Text = "ID:";
			// 
			// txtId
			// 
			this.txtId.Location = new System.Drawing.Point(128, 48);
			this.txtId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtId.Name = "txtId";
			this.txtId.ReadOnly = true;
			this.txtId.Size = new System.Drawing.Size(233, 23);
			this.txtId.TabIndex = 17;
			// 
			// nazivLabel
			// 
			this.nazivLabel.AutoSize = true;
			this.nazivLabel.Location = new System.Drawing.Point(16, 81);
			this.nazivLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.nazivLabel.Name = "nazivLabel";
			this.nazivLabel.Size = new System.Drawing.Size(39, 15);
			this.nazivLabel.TabIndex = 19;
			this.nazivLabel.Text = "Naziv:";
			// 
			// txtNaziv
			// 
			this.txtNaziv.Location = new System.Drawing.Point(128, 78);
			this.txtNaziv.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtNaziv.Name = "txtNaziv";
			this.txtNaziv.Size = new System.Drawing.Size(233, 23);
			this.txtNaziv.TabIndex = 18;
			// 
			// idIzdavacLabel
			// 
			this.idIzdavacLabel.AutoSize = true;
			this.idIzdavacLabel.Location = new System.Drawing.Point(434, 78);
			this.idIzdavacLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.idIzdavacLabel.Name = "idIzdavacLabel";
			this.idIzdavacLabel.Size = new System.Drawing.Size(49, 15);
			this.idIzdavacLabel.TabIndex = 22;
			this.idIzdavacLabel.Text = "Izdavač:";
			// 
			// idDeveloperLabel
			// 
			this.idDeveloperLabel.AutoSize = true;
			this.idDeveloperLabel.Location = new System.Drawing.Point(434, 108);
			this.idDeveloperLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.idDeveloperLabel.Name = "idDeveloperLabel";
			this.idDeveloperLabel.Size = new System.Drawing.Size(63, 15);
			this.idDeveloperLabel.TabIndex = 24;
			this.idDeveloperLabel.Text = "Developer:";
			// 
			// cijenaLabel
			// 
			this.cijenaLabel.AutoSize = true;
			this.cijenaLabel.Location = new System.Drawing.Point(432, 52);
			this.cijenaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.cijenaLabel.Name = "cijenaLabel";
			this.cijenaLabel.Size = new System.Drawing.Size(43, 15);
			this.cijenaLabel.TabIndex = 25;
			this.cijenaLabel.Text = "Cijena:";
			// 
			// txtCijena
			// 
			this.txtCijena.Location = new System.Drawing.Point(544, 48);
			this.txtCijena.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtCijena.Name = "txtCijena";
			this.txtCijena.Size = new System.Drawing.Size(233, 23);
			this.txtCijena.TabIndex = 23;
			// 
			// datumIzdavanjaLabel
			// 
			this.datumIzdavanjaLabel.AutoSize = true;
			this.datumIzdavanjaLabel.Location = new System.Drawing.Point(16, 146);
			this.datumIzdavanjaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.datumIzdavanjaLabel.Name = "datumIzdavanjaLabel";
			this.datumIzdavanjaLabel.Size = new System.Drawing.Size(98, 15);
			this.datumIzdavanjaLabel.TabIndex = 26;
			this.datumIzdavanjaLabel.Text = "Datum Izdavanja:";
			// 
			// idVrstaIgreLabel
			// 
			this.idVrstaIgreLabel.AutoSize = true;
			this.idVrstaIgreLabel.Location = new System.Drawing.Point(16, 108);
			this.idVrstaIgreLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.idVrstaIgreLabel.Name = "idVrstaIgreLabel";
			this.idVrstaIgreLabel.Size = new System.Drawing.Size(59, 15);
			this.idVrstaIgreLabel.TabIndex = 28;
			this.idVrstaIgreLabel.Text = "Vrsta Igre:";
			// 
			// toolStrip1
			// 
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbSpremi,
            this.tsbCancel});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(800, 25);
			this.toolStrip1.TabIndex = 29;
			this.toolStrip1.Text = "toolStrip1";
			this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
			// 
			// tsbSpremi
			// 
			this.tsbSpremi.Image = ((System.Drawing.Image)(resources.GetObject("tsbSpremi.Image")));
			this.tsbSpremi.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsbSpremi.Name = "tsbSpremi";
			this.tsbSpremi.Size = new System.Drawing.Size(64, 22);
			this.tsbSpremi.Text = "Spremi";
			// 
			// tsbCancel
			// 
			this.tsbCancel.Image = ((System.Drawing.Image)(resources.GetObject("tsbCancel.Image")));
			this.tsbCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.tsbCancel.Name = "tsbCancel";
			this.tsbCancel.Size = new System.Drawing.Size(75, 22);
			this.tsbCancel.Text = "Odustani";
			// 
			// cboVrsta
			// 
			this.cboVrsta.FormattingEnabled = true;
			this.cboVrsta.Location = new System.Drawing.Point(128, 108);
			this.cboVrsta.Name = "cboVrsta";
			this.cboVrsta.Size = new System.Drawing.Size(233, 23);
			this.cboVrsta.TabIndex = 30;
			// 
			// cboIzdavac
			// 
			this.cboIzdavac.FormattingEnabled = true;
			this.cboIzdavac.Location = new System.Drawing.Point(544, 78);
			this.cboIzdavac.Name = "cboIzdavac";
			this.cboIzdavac.Size = new System.Drawing.Size(233, 23);
			this.cboIzdavac.TabIndex = 30;
			// 
			// cboDeveloper
			// 
			this.cboDeveloper.FormattingEnabled = true;
			this.cboDeveloper.Location = new System.Drawing.Point(544, 107);
			this.cboDeveloper.Name = "cboDeveloper";
			this.cboDeveloper.Size = new System.Drawing.Size(233, 23);
			this.cboDeveloper.TabIndex = 30;
			// 
			// IgreEdit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 207);
			this.Controls.Add(this.cboDeveloper);
			this.Controls.Add(this.cboIzdavac);
			this.Controls.Add(this.cboVrsta);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.txtDatumIzdavanja);
			this.Controls.Add(this.iDLabel);
			this.Controls.Add(this.txtId);
			this.Controls.Add(this.nazivLabel);
			this.Controls.Add(this.txtNaziv);
			this.Controls.Add(this.idIzdavacLabel);
			this.Controls.Add(this.idDeveloperLabel);
			this.Controls.Add(this.cijenaLabel);
			this.Controls.Add(this.txtCijena);
			this.Controls.Add(this.datumIzdavanjaLabel);
			this.Controls.Add(this.idVrstaIgreLabel);
			this.Name = "IgreEdit";
			this.Text = "Uredi igru";
			this.Load += new System.EventHandler(this.IgreEdit_Load);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtDatumIzdavanja;
		private System.Windows.Forms.Label iDLabel;
		private System.Windows.Forms.TextBox txtId;
		private System.Windows.Forms.Label nazivLabel;
		private System.Windows.Forms.TextBox txtNaziv;
		private System.Windows.Forms.Label idIzdavacLabel;
		private System.Windows.Forms.Label idDeveloperLabel;
		private System.Windows.Forms.Label cijenaLabel;
		private System.Windows.Forms.TextBox txtCijena;
		private System.Windows.Forms.Label datumIzdavanjaLabel;
		private System.Windows.Forms.Label idVrstaIgreLabel;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripButton tsbSpremi;
		private System.Windows.Forms.ToolStripButton tsbCancel;
		private System.Windows.Forms.ComboBox cboVrsta;
		private System.Windows.Forms.ComboBox cboIzdavac;
		private System.Windows.Forms.ComboBox cboDeveloper;
	}
}